function [ Temperature ] = thermalsimCholesky( p, mediumX, mediumY, leftBound, rightBound, topBound, bottomBound )
%THERMALSIMCHOLESKY solves the 2D steady state thermal problem using
%Cholesky factorization
%   INPUT:
%   p:  discretized power density
%   mediumX:    x-dimension of the medium
%   mediumY:    y-dimension of the medium
%	leftBound:	Temperature at the left boundary (x=0), leftBound(j) means
%	the temperature at T(0,j)
%	rightBound:	Temperature at the right boundary (x=N+1)
%	topBound:	Temperature at the top boundary (y=M+1)
%	bottomBound:	Temperature at the bottom boundary (y=0)
%
%   OUTPUT:
%   Temperature: solved thermal map

time1 = clock;

[r, c] = size(p);
totalSize = r*c;
deltaX  = mediumX/(r-1);
deltaY  = mediumY/(c-1);
K    = 157;

%set up B
B= zeros(r,c);
B= -p/K;
B(1,:) = B(1,:)-(1/deltaX^2)*leftBound';
B(r,:) = B(r,:)-(1/deltaX^2)*rightBound';
B(:,1)   = B(:,1)-(1/deltaY^2)*bottomBound;
B(:,c) = B(:,c)-(1/deltaY^2)*topBound;
B =im2col(B',[c r],'distinct');

%set up A
A = zeros(totalSize,totalSize);
for i=1:totalSize
    for j=1:totalSize
       if i==j
           A(i,j) = -2*(1/deltaX^2 + 1/deltaY^2);
           if j+c <= totalSize
               A(i, j+c) = 1/deltaX^2;
           end
           if j-c > 0
               A(i, j-c) = 1/deltaX^2;
           end
           if j+1 <= totalSize
               A(i, j+1) = 1/deltaY^2;
           end
           if j-1 > 0
              A(i, j-1) = 1/deltaY^2;
           end
           if mod(i,c) == 0
               if j+1 <= totalSize
                A(i,j+1) = 0;
               end
           end
           if mod(i,c) == 1
               if j-1 > 0
                A(i,j-1) = 0;
               end
           end
       end 
    end
end


A = -A;
B = -B;
L=zeros(totalSize,totalSize);
for i=1:totalSize
   L(i, i) = sqrt(A(i, i) - L(i, :)*L(i, :)');
   for j=(i + 1):totalSize
      lMult = L(i,:)*transpose(L(j,:));
      lDiagonal = L(i,i);
      L(j, i)=(A(j, i)-lMult)/lDiagonal;
   end
end

%forward substitution on L to get V
Vmat = zeros(totalSize,1);
for i=1:totalSize
    normalized = B(i)/L(i,i);
    Vmat(i) = normalized;
    if i < totalSize
        B(i+1) = B(i+1) - L(i+1,1:i)*Vmat(1:i) ;
    end
end


%now backward substition on L^T to get x
ltrans = L';
x = zeros(totalSize,1);
for i=totalSize:-1:1
    x(i) = Vmat(i)/ltrans(i,i);
    if i > 1
        Vmat(i-1) = Vmat(i-1) - ltrans(i-1,i:totalSize)*x(i:totalSize);
    end
end




Temperature=col2im(x,[c r],[c r],'distinct');

time2 = clock;

elapsed = etime(time2, time1)

thermalplot(Temperature');
title('Cholesky3');
end 