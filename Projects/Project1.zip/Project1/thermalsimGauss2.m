function [ Temperature ] = thermalsimGauss2( p, mediumX, mediumY, leftBound, rightBound, topBound, bottomBound )
%This function solves the 2D steady state thermal problem using Gaussian elimination
%   INPUT:
%   p:  discretized power density
%   mediumX:    x-dimension of the medium
%   mediumY:    y-dimension of the medium
%	leftBound:	Temperature at the left boundary (x=0), leftBound(j) means
%	the temperature at T(0,j)
%	rightBound:	Temperature at the right boundary (x=N+1)
%	topBound:	Temperature at the top boundary (y=M+1)
%	bottomBound:	Temperature at the bottom boundary (y=0)
%
%   OUTPUT:
%   Temperature: solved thermal map


k=157;
[r, c]=size(p);
deltaX=mediumX/(r-1);
deltaY=mediumY/(c-1);
totalSize=r*c;
B=-p/k;

%take system time
t1 = clock;

%Set up B
B(1,:)=B(1,:)-(1/deltaX^2)*leftBound';
B(r,:)=B(r,:)-(1/deltaX^2)*rightBound';
B(:,1)=B(:,1)-(1/deltaY^2)*bottomBound;
B(:,c)=B(:,c)-(1/deltaY^2)*topBound;
B=im2col(B',[c r],'distinct');

%set up A
A = zeros(totalSize,totalSize);
for i=1:totalSize
    for j=1:totalSize
       if i==j
           A(i,j) = -2*(1/deltaX^2 + 1/deltaY^2);
           if j+c <= totalSize
               A(i, j+c) = 1/deltaX^2;
           end
           if j-c > 0
               A(i, j-c) = 1/deltaX^2;
           end
           if j+1 <= totalSize
               A(i, j+1) = 1/deltaY^2;
           end
           if j-1 > 0
              A(i, j-1) = 1/deltaY^2;
           end
           if mod(i,c) == 0
               if j+1 <= totalSize
                A(i,j+1) = 0;
               end
           end
           if mod(i,c) == 1
               if j-1 > 0
                A(i,j-1) = 0;
               end
           end
       end 
    end
end

%step3: implement Gaussian elimination
A = [A, B]; 
[Ax, Ay]=size(A); 
for i=1:Ay 
    for j=i+1:Ax 
        negation = (-A(j,i)/A(i,i));
        elim = (A(i,:).*negation);
        A(j,:) = A(j,:) + elim;
    end 
end 

%once we have to gaussian elim done,
%use backward substition to get the resultVector
resultVector = zeros(Ax, 1 );
for i=Ax:-1:1
    resultVector(i) = ( A(i,Ay) - A(i, 1:Ax)*resultVector )/A(i, i);
end
  
resultMat=col2im(resultVector,[c r],[c r],'distinct');
Temperature=resultMat';

t2 = clock;
elapsed = etime(t2, t1)

thermalplot(Temperature);
title('GaussianElimination-Case3')
end