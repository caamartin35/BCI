function [G,H] = costFcn(Z, x, y, lambda, t)

    bp=size(x,1);
    W=Z(1:bp,1);
    C=Z(bp+1,1);
    squiggly=Z(bp+2:end,1);
    squiggly=squiggly';

    H = Hessian(x, y, W, C, squiggly, lambda, t);
    G = Gradient(x, y, W, C, squiggly, lambda, t);

end

    
       
