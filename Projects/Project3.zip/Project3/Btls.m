function [newZ] = Btls(Z, dZ, x, y)
    s=1;
    newZ=Z;

    while true
        newZ=Z;
        newZ=newZ+s*dZ;
        newW=newZ(1:size(x,1),1);
        newC=newZ(size(x,1)+1,1);
        newSquiggly=newZ(size(x,1)+2:end,1);
        
        if min(newW'*x.*y+newC*y+newSquiggly'-1)>=0
            if min(newSquiggly)>=0
                break;
            end
        end
        
        s=0.5*s;
    end
    
   


end

