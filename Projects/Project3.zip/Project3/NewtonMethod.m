function [newZ] = NewtonMethod(Z, x, y, lambda, t)
    threshold = 0.000001;
    
    while true
        [G, H] = costFcn(Z, x, y, lambda, t);
        e= G'*inv(H)*G;
        dZ=-inv(H)*G;
        %fprintf('e=%d\n', e);
        if abs((e/2))<threshold
            break;
        end
        Z=Btls(Z,dZ,x,y);
    end
    newZ = Z;
end

