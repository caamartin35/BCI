function [Wf, Cf, accuracy] = OptiRun(X, Y, setPara, lambda)
    
    blockSize = length(Y)/6;
    accuracy = zeros(1,6);
    %first level of cross validation
    for i=1:6
        indexes = setdiff(1:size(X,2), (i-1)*blockSize+1:(i-1)*blockSize+blockSize);
        x_test = X(:,(i-1)*blockSize+1:(i-1)*blockSize+blockSize );
        x_train = X(:, indexes);
        y_test = Y(1, (i-1)*blockSize+1:(i-1)*blockSize+blockSize);
        y_train = Y(1, indexes);
        
        squiggly = zeros(length(y_train), 1);
        for k=1:length(y_train)
            squiggly(k, 1) = max(0, 1-y_train(1,k)*(setPara.W'*x_train(:,k)+setPara.C))+0.001;
        end
        Z_init = [setPara.W; setPara.C; squiggly];
        [optiW, optiC] = InteriorPoint(Z_init, x_train, y_train, lambda, setPara);
        y_final = optiW'*x_test + optiC;
        for yi=1:length(y_final)
            if (y_final(1,yi) >= 0)
                y_final(1,yi) = 1;
            else
                y_final(1,yi) = -1;
            end
        end

        accuracy(1,i)=(length(y_final)-sum(abs(y_final-y_test))/2)/length(y_final);
    end
    
    Wf = optiW;
    Cf = optiC;
end

