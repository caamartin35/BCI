function [G] = Gradient(x, y, W, C, squiggly, lambda, t)
   
    len = size(W, 1) + size(C, 1) + size(squiggly,2);
    G=zeros(len,1);
    bp=size(x,1);
    
    for i=1:len
        if i<bp+1
            G(i,1)=2*lambda*W(i,1)-(1/t)*sum((x(i,:).*y)./(W'*x.*y+C*y+(squiggly-1)));
        elseif i==bp+1
            G(i,1)=-(1/t)*sum((y)./(W'*x.*y+C*y+(squiggly-1)));
        else
            G(i,1)=1-(1/t)*1/squiggly(1,i-(bp+1))-(1/t)*1/(W'*x(:,i-(bp+1))*y(1,i-(bp+1))+C*y(1,i-(bp+1))+squiggly(1,i-(bp+1))-1);
        end
    end


end

