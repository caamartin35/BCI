function [H] = Hessian(x, y, W, C, squiggly, lambda, t)


len = size(W,1) + size(C,1) + size(squiggly, 2);
H = zeros(len, len);
bp=size(x,1);

    for i=1:len
        if i<bp+1
            H(i,i)=2*lambda+(1/t)*sum(((x(i,:).*y).^2)./((W'*x.*y+C*y+(squiggly-1)).^2));
            for j=i+1:len
                if j<bp+1
                    H(i,j)=(1/t)*sum((x(i,:).*y.*(x(j,:)).*y)./((W'*x.*y+C*y+(squiggly-1)).^2));
                elseif j==bp+1
                    H(i,j)=(1/t)*sum((x(i,:).*y.*y)./((W'*x.*y+C*y+(squiggly-1)).^2));
                else
                    H(i,j)=(1/t)*(x(i,j-(bp+1))*y(1,j-(bp+1)))/((W'*x(:,j-(bp+1))*y(1,j-(bp+1))+C*y(1,j-(bp+1))+squiggly(1,j-(bp+1))-1)^2);
                end
            end
        elseif i==bp+1
            H(i,i)=(1/t)*sum((y.^2)./((W'*x.*y+C*y+(squiggly-1)).^2));
            for j=i+1:len
                H(i,j)=(1/t)*(y(1,j-(bp+1)))/((W'*x(:,j-(bp+1))*y(1,j-(bp+1))+C*y(1,j-(bp+1))+squiggly(1,j-(bp+1))-1)^2);
            end
        else
            H(i,i)=(1/t)*1/(squiggly(1,i-(bp+1))^2)+1/t*1/((W'*x(:,i-(bp+1))*y(1,i-(bp+1))+C*y(1,i-(bp+1))+squiggly(1,i-(bp+1))-1)^2);
        end
    end

    for i=1:len
        if i<bp+1
            for j=i+1:len
                if j<bp+1
                    H(j,i)=(1/t)*sum((x(i,:).*y.*(x(j,:)).*y)./((W'*x.*y+C*y+(squiggly-1)).^2));
                elseif j==bp+1
                    H(j,i)=(1/t)*sum((x(i,:).*y.*y)./((W'*x.*y+C*y+(squiggly-1)).^2));
                else
                    H(j,i)=(1/t)*(x(i,j-(bp+1))*y(1,j-(bp+1)))/((W'*x(:,j-(bp+1))*y(1,j-(bp+1))+C*y(1,j-(bp+1))+squiggly(1,j-(bp+1))-1)^2);
                end
            end
        elseif i==bp+1
            for j=i+1:len
                H(j,i)=(1/t)*(y(1,j-(bp+1)))/((W'*x(:,j-(bp+1))*y(1,j-(bp+1))+C*y(1,j-(bp+1))+squiggly(1,j-(bp+1))-1)^2);
            end
        end
    end

    


end

