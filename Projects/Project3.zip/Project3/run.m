function [W] = run(dataset)
    
    load(dataset);
    x = [class{1} class{2}];
    y = ones(1,240);
    y(121:240) = -1;
    setParams = struct('t', 10, 'beta', 15, 'Tmax', 1000000, 'W', ones(204,1), 'C', 1);
    lambda = getOptLambda(x, y, setParams);
    fprintf('Optimal Lambda: %d\n', lambda);
    [W, C, accuracy] = OptiRun(x, y, setParams, lambda);
    [sortedW, sortedI] = sort(abs(W), 'descend');
    fprintf('TopW: %d\n', sortedW(1:5, 1));
    fprintf('TopWIndexes: %d\n', sortedI(1:5, 1));
    fprintf('acc: %d\n', accuracy);
    fprintf('C: %d\n', C);
    fprintf('Mean Accuracy: %d\n', mean(accuracy));
    fprintf('STD Accuracy: %d\n', std(accuracy));
    show_chanWeights(W);

    clear;
end