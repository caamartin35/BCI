function optLambda = getOptLambda(X, Y, setPara)
% Get the optimal lamda
%
% INPUTS:
%   X(MxN) : trData(i,j) is the i-th feature from the j-th trial
%   Y(Nx1): trData(j) is the label of the j-th trial (1 or -1)
%   setPara : Initialized parameters
%            setPara.t      
%            setPara.beta   
%            setPara.Tmax   
%            setPara.tol    
%            setPara.W      
%            setPara.C      
%
% OUTPUTS:
%   optiLamda: Optimal lamda value 
%
% @ 2011 Kiho Kwak -- kkwak@andrew.cmu.edu
    
    lambdas = [0.01 1 100 10000];
    blockSize = length(Y)/6;
    
    indexes = setdiff(1:size(X,2), 1:blockSize);
    x_test_1 = X(:, 1:blockSize);
    x_train_1 = X(:, indexes);
    y_test_1 = Y(1, 1:blockSize);
    y_train_1 = Y(1, indexes);

    lambda_accuracies = zeros(1, length(lambdas));
    for lambda=1:length(lambdas) 
        %disp('lambda=' + lambdas(1, lambda));
        fprintf('lambda=%d\n', lambdas(1, lambda));
        accuracy = zeros(1,5);
        for j=1:5
             fprintf('j=%d\n', j);
            indexes = setdiff(1:size(x_train_1,2), (j-1)*blockSize+1:(j-1)*blockSize+blockSize);
            x_test_2 = x_train_1(:, (j-1)*blockSize+1:(j-1)*blockSize+blockSize);
            x_train_2 = x_train_1(:, indexes);
            y_test_2 = y_train_1(1, (j-1)*blockSize+1:(j-1)*blockSize+blockSize);
            y_train_2 = y_train_1(1, indexes);
            squiggly = zeros(length(y_train_2), 1);
            
            for k=1:length(y_train_2)
                squiggly(k, 1) = max(0, 1-y_train_2(1,k)*(setPara.W'*x_train_2(:,k)+setPara.C))+0.001;
            end
            
            Z_init = [setPara.W; setPara.C; squiggly];
            [optiW, optiC] = InteriorPoint(Z_init, x_train_2, y_train_2, lambdas(1,lambda), setPara);
            y_final = optiW'*x_test_2 + optiC;
            
            for yi=1:length(y_final)
                if (y_final(1,yi) >= 0)
                    y_final(1,yi) = 1;
                else
                    y_final(1,yi) = -1;
                end
            end
            
            accuracy(1,j)=(length(y_final)-sum(abs(y_final-y_test_2))/2)/length(y_final);
        end

        lambda_accuracies(1, lambda) = mean(accuracy);
    end
    
    optLambda=lambdas(1,find(max(lambda_accuracies)));

end