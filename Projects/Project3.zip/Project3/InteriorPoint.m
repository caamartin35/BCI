function [W, C] = InteriorPoint(Z_init, x, y, lambda, setPara)
    beta = setPara.beta;
    Tmax = setPara.Tmax;
    t = setPara.t;
    Z = Z_init;
    x = x/20;
    
    while (t<Tmax)
        Z = NewtonMethod(Z, x, y,lambda, t);
        t = beta*t;
        fprintf('t=%d\n', t);
    end
    
    W = Z(1:size(x,1),1);
    C = Z(size(x,1)+1,1);
end
