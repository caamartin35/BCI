function [imgOut] = imgRecover(imgIn, blkSize, numSample)
% Recover the input image from a small size samples
%
% INPUT:
%   imgIn: input image
%   blkSize: block size
%   numSample: how many samples in each block
%
% OUTPUT:
%   imgOut: recovered image
%
% @ 2011 Huapeng Zhou -- huapengz@andrew.cmu.edu
    original = imgRead(imgIn);
    m = floor(numSample/6);
    [height, width] = size(original);
    blocks_x = width/blkSize;
    blocks_y = height/blkSize;
    lambdas = linspace(numSample/2,numSample,2);
    M = 20;
    
    CFinal = zeros(height, width);

    
    T = zeros(blkSize*blkSize, blkSize*blkSize);
    
    %Build the transformation matrix
    for tx=1:blkSize
        for ty=1:blkSize
            for u=1:blkSize
                for v=1:blkSize
                    if (u == 1 && v == 1)
                        T((tx-1)*blkSize + ty, (u-1)*blkSize + v) = sqrt(1/blkSize)*sqrt(1/blkSize)*cos((pi*(2*tx-1)*(u-1))/(2*blkSize))*cos((pi*(2*ty-1)*(v-1))/(2*blkSize));
                    end
                    if (u == 1 && v > 1)
                        T((tx-1)*blkSize + ty, (u-1)*blkSize + v) = sqrt(1/blkSize)*sqrt(2/blkSize)*cos((pi*(2*tx-1)*(u-1))/(2*blkSize))*cos((pi*(2*ty-1)*(v-1))/(2*blkSize));
                    end
                    if (u > 1 && v == 1)
                        T((tx-1)*blkSize + ty, (u-1)*blkSize + v) = sqrt(2/blkSize)*sqrt(1/blkSize)*cos((pi*(2*tx-1)*(u-1))/(2*blkSize))*cos((pi*(2*ty-1)*(v-1))/(2*blkSize));
                    end
                    if (u > 1 && v > 1)
                        T((tx-1)*blkSize + ty, (u-1)*blkSize + v) = sqrt(2/blkSize)*sqrt(2/blkSize)*cos((pi*(2*tx-1)*(u-1))/(2*blkSize))*cos((pi*(2*ty-1)*(v-1))/(2*blkSize));
                    end
                end
            end
        end
    end
    
   
    
    %loop over blocks in image
    curBlock = 0;
    for x=1:blocks_x
        for y=1:blocks_y
            curBlock = curBlock + 1
            startY = (y-1)*blkSize + 1;
            endY = y*blkSize;
            startX = (x-1)*blkSize + 1;
            endX = x*blkSize;
            block = original(startY:endY, startX:endX);
            blockVect = reshape(block.',[],1);
           
            
            %get trans matrix for block
            Tblock = T;
            
            lambdasError = [];
            alphas = [];
            %do cross validation M times to find best lambda
            for lambda = lambdas
                errorSum = 0;
                alphaSum = zeros(blkSize*blkSize, 1);
              
                for time=1:M
                    sample_indexes = randsample(blkSize*blkSize, numSample);
                    test_indexes = sample_indexes(1:m);
                    test_indexes = sort(test_indexes);
                    train_indexes = sample_indexes(m+1:length(sample_indexes));
                    train_indexes = sort(train_indexes);
                
                    %only get sampled rows
                    blockSample = blockVect(train_indexes);
                    B_test = blockVect(test_indexes);
         
                    %only get sampled trans matrix rows
                    Ttrain = Tblock(train_indexes, :);
                    Ttest = Tblock(test_indexes, :);
                    
                    %OMP
                    omega = [];
                    B=blockSample;
                    F=B;
                    A=normc(Ttrain);
                    alpha=[];
                    for p=1:lambda
                        theta = zeros(1, blkSize*blkSize);
                        for i=1:blkSize*blkSize
                            theta(i) = dot(A(:,i),F);
                        end
                        s=find(theta==max(theta));
                        
                        if (~ismember(s, omega))
                            omega = cat(2, omega, s);
                        end
                     
                        alpha = A(:, omega)\B;
                        F = B-A(:,omega)*alpha;
                    end
                    
                    alpha_full = zeros(blkSize*blkSize, 1);
                    for i=1:length(omega)
                        alpha_full(omega(i)) = alpha(i);
                    end
                    B_train = Ttest*alpha_full;
                    error = mean((B_test - B_train).^2);
                    errorSum = errorSum + error;
                    alphaSum = alphaSum + alpha_full;
                end
                
                lambdasError(end+1) = errorSum/M;
                alphas(:, end+1) = alphaSum./M;
            end
            
            
            index=find(lambdasError==min(lambdasError));
            BFinal = Tblock*alphas(:, index);
            
            FinalBlock = col2im(BFinal, [blkSize blkSize], [blkSize blkSize], 'distinct');
            FinalBlock = FinalBlock';
            CFinal(startY:endY, startX:endX) = FinalBlock;
        end
    end
    
    CFinal = medfilt2(CFinal);
    imgOut = CFinal;
    imgShow(CFinal);
    
end