function [quality] = measureQuality(original, recovered)

	[height, width] = size(original);
	sum = 0;
	for x=1:width
		for y=1:height
			sum = sum + (recovered(y,x) - original(y,x))^2;
		end
	end
	
	quality = (sum/(width*height));
end
	